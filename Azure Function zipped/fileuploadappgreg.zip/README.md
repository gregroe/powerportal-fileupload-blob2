# powerportal-fileupload-to-azureblob
A sample solution that demonstrates securely uploading large Gb files to azure blob via Power Apps Portal 
